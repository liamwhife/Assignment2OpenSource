﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Using an array to convert Centimetres to Inches
            double[] Conversion = new double[3];
            Conversion[1] = 0.393701;

            Conversion[0] = Convert.ToInt32(textBox1.Text);
            Conversion[2] = Conversion[0] * Conversion[1];
            label1.Text = Conversion[2].ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Coverting Metres to Feet
            double metres;
            double feet;
            feet = 3.28084;

            metres = Convert.ToInt32(textBox1.Text);
            feet = metres * feet;
            label2.Text = feet.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Celsius to Fahrenheit
            double Celsius;
            double Fahrenheit;

            Celsius = Convert.ToInt32(textBox1.Text);
            Fahrenheit = Celsius * 9 / 5 + 32; 
            label3.Text = Fahrenheit.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Centimetres to Feet 
            double Cm;
            double feet;
            feet = 0.0328084;

            Cm = Convert.ToInt32(textBox1.Text);
            feet = Cm * feet;
            label4.Text = feet.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Kilometres to Miles
            double Kilometres;
            double Miles;
            Miles = 0.621371;

            Kilometres = Convert.ToInt32(textBox1.Text);
            Miles = Kilometres * Miles;
            label5.Text = Miles.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
