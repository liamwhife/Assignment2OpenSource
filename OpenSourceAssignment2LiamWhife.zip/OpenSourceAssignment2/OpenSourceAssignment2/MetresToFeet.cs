﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpenSourceAssignment2
{
    public partial class MetresToFeet : Form
    {
        public MetresToFeet()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double metre;
            double feet;

            metre = Convert.ToInt32(textBox1.Text);
            feet = 3.28084;
            feet = metre * feet;
            MessageBox.Show(feet.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
